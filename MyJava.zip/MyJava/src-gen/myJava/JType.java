/**
 */
package myJava;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>JType</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see myJava.MyJavaPackage#getJType()
 * @model
 * @generated
 */
public interface JType extends EObject {
} // JType
