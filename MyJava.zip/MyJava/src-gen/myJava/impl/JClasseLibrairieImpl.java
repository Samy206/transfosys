/**
 */
package myJava.impl;

import myJava.JClasseLibrairie;
import myJava.MyJavaPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>JClasse Librairie</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class JClasseLibrairieImpl extends JTypeDeclImpl implements JClasseLibrairie {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JClasseLibrairieImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyJavaPackage.Literals.JCLASSE_LIBRAIRIE;
	}

} //JClasseLibrairieImpl
