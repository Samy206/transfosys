/**
 */
package myJava.impl;

import myJava.JInstruction;
import myJava.MyJavaPackage;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.MinimalEObjectImpl;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>JInstruction</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class JInstructionImpl extends MinimalEObjectImpl.Container implements JInstruction {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JInstructionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyJavaPackage.Literals.JINSTRUCTION;
	}

} //JInstructionImpl
