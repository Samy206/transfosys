/**
 */
package myJava.impl;

import myJava.JExpression;
import myJava.MyJavaPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>JExpression</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public abstract class JExpressionImpl extends JInstructionImpl implements JExpression {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JExpressionImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyJavaPackage.Literals.JEXPRESSION;
	}

} //JExpressionImpl
