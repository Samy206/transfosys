/**
 */
package myJava.impl;

import myJava.JParametre;
import myJava.MyJavaPackage;

import org.eclipse.emf.ecore.EClass;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>JParametre</b></em>'.
 * <!-- end-user-doc -->
 *
 * @generated
 */
public class JParametreImpl extends DonneeTypeeImpl implements JParametre {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected JParametreImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return MyJavaPackage.Literals.JPARAMETRE;
	}

} //JParametreImpl
