/**
 */
package myJava;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>JParametre</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see myJava.MyJavaPackage#getJParametre()
 * @model
 * @generated
 */
public interface JParametre extends DonneeTypee {
} // JParametre
