/**
 */
package myJava;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>JAttribut</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link myJava.JAttribut#getVal_init <em>Val init</em>}</li>
 * </ul>
 *
 * @see myJava.MyJavaPackage#getJAttribut()
 * @model
 * @generated
 */
public interface JAttribut extends DonneeTypee {
	/**
	 * Returns the value of the '<em><b>Val init</b></em>' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Val init</em>' containment reference.
	 * @see #setVal_init(JExpression)
	 * @see myJava.MyJavaPackage#getJAttribut_Val_init()
	 * @model containment="true"
	 * @generated
	 */
	JExpression getVal_init();

	/**
	 * Sets the value of the '{@link myJava.JAttribut#getVal_init <em>Val init</em>}' containment reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Val init</em>' containment reference.
	 * @see #getVal_init()
	 * @generated
	 */
	void setVal_init(JExpression value);

} // JAttribut
