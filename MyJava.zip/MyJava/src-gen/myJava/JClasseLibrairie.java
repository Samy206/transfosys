/**
 */
package myJava;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>JClasse Librairie</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see myJava.MyJavaPackage#getJClasseLibrairie()
 * @model
 * @generated
 */
public interface JClasseLibrairie extends JTypeDecl {
} // JClasseLibrairie
