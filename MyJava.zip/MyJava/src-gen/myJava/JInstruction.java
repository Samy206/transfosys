/**
 */
package myJava;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>JInstruction</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see myJava.MyJavaPackage#getJInstruction()
 * @model abstract="true"
 * @generated
 */
public interface JInstruction extends EObject {
} // JInstruction
