/**
 */
package myJava;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>JConstructeur</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see myJava.MyJavaPackage#getJConstructeur()
 * @model
 * @generated
 */
public interface JConstructeur extends JMethode {
} // JConstructeur
