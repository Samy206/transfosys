/**
 */
package myJava;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>JExpression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see myJava.MyJavaPackage#getJExpression()
 * @model abstract="true"
 * @generated
 */
public interface JExpression extends JInstruction {
} // JExpression
