package librairie;

public interface Port {
	public void send();
}
